# 🛒 Sales Management System API

Backend REST para gestión de ventas, inventario y pagos.
Desarrollado con Spring Boot siguiendo buenas prácticas de arquitectura en capas.

---

# 📌 Características

* Gestión de clientes
* Gestión de productos y stock
* Creación de órdenes (ventas)
* Manejo de pagos
* Control de inventario
* Cálculo de totales
* Validaciones de negocio
* Arquitectura escalable

---

# 🏗️ Arquitectura

Estructura basada en capas:

```
controller → service → repository → entity
                ↓
              dto
```

---

# 📦 Modelo de Datos

## 👤 Customer

Representa a los clientes del sistema.

* id: Long
* name: String
* email: String (único)
* phone: String
* address: String
* createdAt: LocalDateTime

---

## 📦 Product

* id: Long
* name: String
* description: String
* price: BigDecimal
* stock: Integer
* active: boolean
* createdAt: LocalDateTime

---

## 🧾 Order

* id: Long
* customer: Customer (ManyToOne)
* status: OrderStatus
* total: BigDecimal
* createdAt: LocalDateTime

Estados:

* PENDING
* PAID
* CANCELLED

---

## 🧱 OrderDetail

* id: Long
* order: Order (ManyToOne)
* product: Product (ManyToOne)
* quantity: Integer
* price: BigDecimal (precio histórico)
* subtotal: BigDecimal

---

## 💳 Payment

* id: Long
* order: Order (OneToOne)
* amount: BigDecimal
* method: PaymentMethod
* paidAt: LocalDateTime

Métodos:

* CASH
* CARD
* TRANSFER

---

## 📊 StockMovement

* id: Long
* product: Product (ManyToOne)
* type: MovementType (IN / OUT)
* quantity: Integer
* date: LocalDateTime

---

## 🏷️ Category (Opcional)

* id: Long
* name: String

Relación:

* Product → ManyToOne Category

---

## 🎟️ Coupon (Opcional)

* id: Long
* code: String
* discount: BigDecimal
* active: boolean

---

# 🔁 Relaciones

* Customer 1 → N Orders
* Order 1 → N OrderDetails
* Product 1 → N OrderDetails
* Order 1 → 1 Payment
* Product 1 → N StockMovements

---

# ⚙️ Lógica de Negocio

## 🛒 Crear Orden

Proceso:

1. Validar existencia de cliente
2. Validar productos
3. Verificar stock disponible
4. Calcular subtotales
5. Calcular total
6. Guardar orden y detalles
7. Descontar stock
8. Registrar movimiento de inventario

Reglas:

* No se permite vender sin stock
* El precio se guarda en OrderDetail (histórico)
* Todo se ejecuta en transacción

---

## 💳 Registrar Pago

1. Validar orden existente
2. Validar que no esté pagada
3. Registrar pago
4. Cambiar estado a PAID

---

## ❌ Cancelar Orden

1. Validar estado (no cancelada)
2. Restaurar stock
3. Registrar movimiento IN
4. Cambiar estado a CANCELLED

---

# 🔐 Validaciones

* Email único
* Stock ≥ 0
* Cantidad > 0
* Precio > 0
* Orden no modificable si está PAID

---

# 📡 API Endpoints

## Customers

* POST /customers
* GET /customers
* GET /customers/{id}

## Products

* POST /products
* GET /products
* PATCH /products/{id}/stock

## Orders

* POST /orders
* GET /orders
* GET /orders/{id}
* POST /orders/{id}/cancel

## Payments

* POST /payments

---

# 🧠 DTOs

Ejemplo CreateOrderRequest:

```
{
  "customerId": 1,
  "items": [
    {
      "productId": 2,
      "quantity": 3
    }
  ]
}
```

---

# 🔄 Transacciones

Se usa @Transactional en:

* creación de órdenes
* cancelación
* pagos

---

# 🚨 Manejo de Errores

Global con @ControllerAdvice:

* ResourceNotFoundException
* BusinessException
* ValidationException

---

# 🧪 Testing

* Unit tests (Service)
* Integration tests (Controller)

---

# 🛠️ Tecnologías

* Spring Boot
* Spring Data JPA
* Spring Web
* Hibernate
* Base de datos: PostgreSQL o MySQL

---

# 📈 Mejoras futuras

* Autenticación con JWT (Spring Security)
* Paginación y filtros
* Reportes (ventas por fecha)
* Dashboard
* Notificaciones

---

# 🚀 Cómo ejecutar

1. Clonar repositorio
2. Configurar application.properties
3. Ejecutar:

```
mvn spring-boot:run
```

---