package com.sistema.ventas.enums;

public enum MovementType {
    IN,
    OUT
}
