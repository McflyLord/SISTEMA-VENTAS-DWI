package com.sistema.ventas.enums;

public enum OrderStatus {
    PENDING,
    PAID,
    CANCELLED
}
