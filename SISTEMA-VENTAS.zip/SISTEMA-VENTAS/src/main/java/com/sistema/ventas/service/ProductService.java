package com.sistema.ventas.service;

import com.sistema.ventas.dto.ProductRequest;
import com.sistema.ventas.dto.ProductResponse;
import com.sistema.ventas.dto.StockUpdateRequest;
import com.sistema.ventas.entity.Category;
import com.sistema.ventas.entity.Product;
import com.sistema.ventas.entity.StockMovement;
import com.sistema.ventas.enums.MovementType;
import com.sistema.ventas.exception.ResourceNotFoundException;
import com.sistema.ventas.repository.CategoryRepository;
import com.sistema.ventas.repository.ProductRepository;
import com.sistema.ventas.repository.StockMovementRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;
    private final StockMovementRepository stockMovementRepository;

    @Transactional
    public ProductResponse create(ProductRequest request) {
        Product product = Product.builder()
                .name(request.getName())
                .description(request.getDescription())
                .price(request.getPrice())
                .stock(request.getStock() != null ? request.getStock() : 0)
                .active(true)
                .build();

        if (request.getCategoryId() != null) {
            Category category = categoryRepository.findById(request.getCategoryId())
                    .orElseThrow(() -> new ResourceNotFoundException("Categoría", request.getCategoryId()));
            product.setCategory(category);
        }

        Product saved = productRepository.save(product);

        // Registrar movimiento de stock inicial si hay stock
        if (saved.getStock() > 0) {
            StockMovement movement = StockMovement.builder()
                    .product(saved)
                    .type(MovementType.IN)
                    .quantity(saved.getStock())
                    .build();
            stockMovementRepository.save(movement);
        }

        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<ProductResponse> findAll() {
        return productRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public ProductResponse findById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Producto", id));
        return toResponse(product);
    }

    @Transactional(readOnly = true)
    public Product findEntityById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Producto", id));
    }

    @Transactional
    public ProductResponse updateStock(Long id, StockUpdateRequest request) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Producto", id));

        int difference = request.getStock() - product.getStock();
        product.setStock(request.getStock());
        productRepository.save(product);

        // Registrar movimiento de stock
        if (difference != 0) {
            StockMovement movement = StockMovement.builder()
                    .product(product)
                    .type(difference > 0 ? MovementType.IN : MovementType.OUT)
                    .quantity(Math.abs(difference))
                    .build();
            stockMovementRepository.save(movement);
        }

        return toResponse(product);
    }

    private ProductResponse toResponse(Product product) {
        return ProductResponse.builder()
                .id(product.getId())
                .name(product.getName())
                .description(product.getDescription())
                .price(product.getPrice())
                .stock(product.getStock())
                .active(product.isActive())
                .categoryName(product.getCategory() != null ? product.getCategory().getName() : null)
                .createdAt(product.getCreatedAt())
                .build();
    }
}
