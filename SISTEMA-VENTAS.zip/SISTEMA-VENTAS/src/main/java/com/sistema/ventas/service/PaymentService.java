package com.sistema.ventas.service;

import com.sistema.ventas.dto.PaymentRequest;
import com.sistema.ventas.dto.PaymentResponse;
import com.sistema.ventas.entity.Order;
import com.sistema.ventas.entity.Payment;
import com.sistema.ventas.enums.OrderStatus;
import com.sistema.ventas.exception.BusinessException;
import com.sistema.ventas.exception.ResourceNotFoundException;
import com.sistema.ventas.repository.OrderRepository;
import com.sistema.ventas.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderRepository orderRepository;

    @Transactional
    public PaymentResponse create(PaymentRequest request) {
        // 1. Validar orden existente
        Order order = orderRepository.findById(request.getOrderId())
                .orElseThrow(() -> new ResourceNotFoundException("Orden", request.getOrderId()));

        // 2. Validar que no esté pagada
        if (order.getStatus() == OrderStatus.PAID) {
            throw new BusinessException("La orden ya fue pagada");
        }

        if (order.getStatus() == OrderStatus.CANCELLED) {
            throw new BusinessException("No se puede pagar una orden cancelada");
        }

        if (paymentRepository.existsByOrderId(request.getOrderId())) {
            throw new BusinessException("Ya existe un pago registrado para esta orden");
        }

        // 3. Registrar pago
        Payment payment = Payment.builder()
                .order(order)
                .amount(order.getTotal())
                .method(request.getMethod())
                .build();

        Payment saved = paymentRepository.save(payment);

        // 4. Cambiar estado a PAID
        order.setStatus(OrderStatus.PAID);
        orderRepository.save(order);

        return toResponse(saved);
    }

    private PaymentResponse toResponse(Payment payment) {
        return PaymentResponse.builder()
                .id(payment.getId())
                .orderId(payment.getOrder().getId())
                .amount(payment.getAmount())
                .method(payment.getMethod().name())
                .paidAt(payment.getPaidAt())
                .build();
    }
}
