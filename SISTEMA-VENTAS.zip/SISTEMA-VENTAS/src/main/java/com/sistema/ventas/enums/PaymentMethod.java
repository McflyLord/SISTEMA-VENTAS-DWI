package com.sistema.ventas.enums;

public enum PaymentMethod {
    CASH,
    CARD,
    TRANSFER
}
