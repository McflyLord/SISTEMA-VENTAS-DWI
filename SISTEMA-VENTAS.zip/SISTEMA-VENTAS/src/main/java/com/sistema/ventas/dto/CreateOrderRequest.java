package com.sistema.ventas.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CreateOrderRequest {

    @NotNull(message = "El ID del cliente es obligatorio")
    private Long customerId;

    @NotEmpty(message = "La orden debe tener al menos un item")
    @Valid
    private List<OrderItemRequest> items;
}
