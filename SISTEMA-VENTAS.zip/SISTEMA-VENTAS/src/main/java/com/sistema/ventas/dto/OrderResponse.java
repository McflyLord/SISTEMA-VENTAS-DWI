package com.sistema.ventas.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OrderResponse {

    private Long id;
    private String customerName;
    private Long customerId;
    private String status;
    private BigDecimal total;
    private LocalDateTime createdAt;
    private List<OrderDetailResponse> details;
}
