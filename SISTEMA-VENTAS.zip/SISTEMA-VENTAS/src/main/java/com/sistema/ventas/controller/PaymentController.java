package com.sistema.ventas.controller;

import com.sistema.ventas.dto.PaymentRequest;
import com.sistema.ventas.dto.PaymentResponse;
import com.sistema.ventas.service.PaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @PostMapping
    public ResponseEntity<PaymentResponse> create(@Valid @RequestBody PaymentRequest request) {
        PaymentResponse response = paymentService.create(request);
        return new ResponseEntity<>(response, HttpStatus.CREATED);
    }
}
