package com.sistema.ventas.service;

import com.sistema.ventas.dto.*;
import com.sistema.ventas.entity.*;
import com.sistema.ventas.enums.MovementType;
import com.sistema.ventas.enums.OrderStatus;
import com.sistema.ventas.exception.BusinessException;
import com.sistema.ventas.exception.ResourceNotFoundException;
import com.sistema.ventas.repository.OrderDetailRepository;
import com.sistema.ventas.repository.OrderRepository;
import com.sistema.ventas.repository.ProductRepository;
import com.sistema.ventas.repository.StockMovementRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderDetailRepository orderDetailRepository;
    private final ProductRepository productRepository;
    private final StockMovementRepository stockMovementRepository;
    private final CustomerService customerService;

    @Transactional
    public OrderResponse create(CreateOrderRequest request) {
        // 1. Validar existencia de cliente
        Customer customer = customerService.findEntityById(request.getCustomerId());

        // 2. Crear la orden
        Order order = Order.builder()
                .customer(customer)
                .status(OrderStatus.PENDING)
                .total(BigDecimal.ZERO)
                .details(new ArrayList<>())
                .build();

        BigDecimal total = BigDecimal.ZERO;
        List<OrderDetail> details = new ArrayList<>();
        List<StockMovement> movements = new ArrayList<>();

        for (OrderItemRequest item : request.getItems()) {
            // 3. Validar producto
            Product product = productRepository.findById(item.getProductId())
                    .orElseThrow(() -> new ResourceNotFoundException("Producto", item.getProductId()));

            // 4. Verificar stock disponible
            if (product.getStock() < item.getQuantity()) {
                throw new BusinessException(
                        String.format("Stock insuficiente para el producto '%s'. Disponible: %d, Solicitado: %d",
                                product.getName(), product.getStock(), item.getQuantity()));
            }

            // 5. Calcular subtotal (precio histórico)
            BigDecimal subtotal = product.getPrice().multiply(BigDecimal.valueOf(item.getQuantity()));

            OrderDetail detail = OrderDetail.builder()
                    .order(order)
                    .product(product)
                    .quantity(item.getQuantity())
                    .price(product.getPrice())
                    .subtotal(subtotal)
                    .build();

            details.add(detail);
            total = total.add(subtotal);

            // 7. Descontar stock
            product.setStock(product.getStock() - item.getQuantity());
            productRepository.save(product);

            // 8. Registrar movimiento de inventario
            StockMovement movement = StockMovement.builder()
                    .product(product)
                    .type(MovementType.OUT)
                    .quantity(item.getQuantity())
                    .build();
            movements.add(movement);
        }

        // 6. Guardar orden y detalles
        order.setTotal(total);
        order.setDetails(details);
        Order savedOrder = orderRepository.save(order);
        stockMovementRepository.saveAll(movements);

        return toResponse(savedOrder);
    }

    @Transactional(readOnly = true)
    public List<OrderResponse> findAll() {
        return orderRepository.findAll().stream()
                .map(this::toResponse)
                .toList();
    }

    @Transactional(readOnly = true)
    public OrderResponse findById(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Orden", id));
        return toResponse(order);
    }

    @Transactional
    public OrderResponse cancel(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Orden", id));

        // 1. Validar estado
        if (order.getStatus() == OrderStatus.CANCELLED) {
            throw new BusinessException("La orden ya está cancelada");
        }
        if (order.getStatus() == OrderStatus.PAID) {
            throw new BusinessException("No se puede cancelar una orden ya pagada");
        }

        // 2. Restaurar stock y 3. Registrar movimiento IN
        for (OrderDetail detail : order.getDetails()) {
            Product product = detail.getProduct();
            product.setStock(product.getStock() + detail.getQuantity());
            productRepository.save(product);

            StockMovement movement = StockMovement.builder()
                    .product(product)
                    .type(MovementType.IN)
                    .quantity(detail.getQuantity())
                    .build();
            stockMovementRepository.save(movement);
        }

        // 4. Cambiar estado
        order.setStatus(OrderStatus.CANCELLED);
        Order savedOrder = orderRepository.save(order);

        return toResponse(savedOrder);
    }

    private OrderResponse toResponse(Order order) {
        List<OrderDetailResponse> detailResponses = order.getDetails().stream()
                .map(detail -> OrderDetailResponse.builder()
                        .id(detail.getId())
                        .productId(detail.getProduct().getId())
                        .productName(detail.getProduct().getName())
                        .quantity(detail.getQuantity())
                        .price(detail.getPrice())
                        .subtotal(detail.getSubtotal())
                        .build())
                .toList();

        return OrderResponse.builder()
                .id(order.getId())
                .customerId(order.getCustomer().getId())
                .customerName(order.getCustomer().getName())
                .status(order.getStatus().name())
                .total(order.getTotal())
                .createdAt(order.getCreatedAt())
                .details(detailResponses)
                .build();
    }
}
